Game.LoadMod("https://tobi914.github.io/AutoCookieClicker/script/autoCookieClicker.js");
